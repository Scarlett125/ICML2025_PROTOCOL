# losses package
from . import loss
from . import losses_POT
from . import losses_Reclass
from . import ramps 